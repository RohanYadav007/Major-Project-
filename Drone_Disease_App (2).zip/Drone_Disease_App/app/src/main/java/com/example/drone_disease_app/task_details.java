package com.example.drone_disease_app;

public class task_details {
    String id,type,rdate,rtime;

    public task_details(String id, String type,  String rdate,String rtime){
        this.id=id;
        this.type=type;

        this.rdate=rdate;
        this.rtime=rtime;


    }
}
