package com.example.drone_disease_app;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class view_task extends AppCompatActivity {
    public static ArrayList id,type,rdate,rtime;


    public static ArrayList<task_details> arrayList = new ArrayList<task_details>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_task);
        final ListView list = findViewById(R.id.list);
        Log.d("size",id.size()+"");
        for(int i=0;i<id.size();i++)
        {
            Log.d("id",id.get(i)+"");
            Log.d("type",type.get(i)+"");

            Log.d("rdate",rdate.get(i)+"");
            Log.d("rtime",rtime.get(i)+"");

            arrayList.add(new task_details(id.get(i).toString(),
                    type.get(i).toString(),
                    rdate.get(i).toString(),rtime.get(i).toString()));

        }


        CustomAdapter1 customAdapter = new CustomAdapter1(this, arrayList);
        list.setAdapter(customAdapter);
    }
}