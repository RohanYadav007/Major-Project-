package com.example.drone_disease_app;



public class Global {
    public static final String url = "http://192.168.119.120:8084/Drone_Disease_Web/";

}
