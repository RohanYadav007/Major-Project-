package com.example.drone_disease_app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    ImageView iv;
    Intent i1,i2;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.b1);
        tv = findViewById(R.id.tv);
        b2 = findViewById(R.id.b2);
        b2.setVisibility(View.GONE);
        iv=(ImageView) findViewById(R.id.iv);
        i1=new Intent(this,view_task.class);
        i2=new Intent(this,Display_Info.class);

        Picasso.with(getApplicationContext())
                .load(Global.url + "1.png")
                .into(iv);



        final Handler handler = new Handler();
        Timer timer = new Timer();
        TimerTask doAsynchronousTask = new TimerTask()
        {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    public void run() {
                        try
                        {

                            get_image_num();
                        }
                        catch (Exception e)
                        {

                        }
                    }
                });
            }
        };
        timer.schedule(doAsynchronousTask, 0, 5000); //execute in every 60s*



        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent i = new Intent(MainActivity.this, View_Image.class);
                startActivity(i2);
            }
        });
//        b2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                try {
//                    get_details();
//                }catch(Exception e)
//                {
//
//                    e.printStackTrace();
//                }
//
//            }
//        });

    }
    public void get_details() throws IOException, JSONException {
        URL url = new URL(Global.url + "get_details");
        JSONObject jsn = new JSONObject();



        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(policy);
        String response = null;
        response = HttpConnection.getResponse(url, jsn);
        Log.d("response",response);
        view_task.id=new ArrayList();
        view_task.type=new ArrayList();

        view_task.rdate=new ArrayList();
        view_task.rtime=new ArrayList();

        view_task.arrayList=new ArrayList();


        String arr[]=response.split("@@");
        for(int i=0;i<arr.length;i++)
        {
            String arr1[]=arr[i].split("#");
            view_task.id.add(arr1[0]);
            view_task.type.add(arr1[1]);

            view_task.rdate.add(arr1[2]);
            view_task.rtime.add(arr1[3]);




        }
        startActivity(i1);



    }
    public void get_image_num() throws IOException, JSONException {
        URL url = new URL(Global.url + "get_image_num");
        JSONObject jsn = new JSONObject();



        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(policy);
        String response = null;
        response = HttpConnection.getResponse(url, jsn);
        Log.d("response",response);
        String a[]=response.split("#");


        Picasso.with(getApplicationContext())
                .load(Global.url + a[0]+".png")
                .into(iv);
        tv.setText(a[1]);
        if(a[1].equalsIgnoreCase("disease"))
        {

            b2.setVisibility(View.VISIBLE);
        }
        else{
            b2.setVisibility(View.GONE);
        }




    }


}