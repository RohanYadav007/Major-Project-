package com.example.drone_disease_app;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

class CustomAdapter1 implements ListAdapter {
    ArrayList<task_details> arrayList;
    ArrayAdapter<String> arrayAdapter;
    Context context;
    TextView tv;
    String type="";
    String id,tid,comment,msg,lat,lon,pdate,ptime,status,accepted_by;


    public CustomAdapter1(Context context, ArrayList<task_details> arrayList) {
        this.arrayList=arrayList;
        this.context=context;





    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
    @Override
    public boolean isEnabled(int position) {
        return true;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final task_details pd = arrayList.get(position);
        if(convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.list_row1, null);
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            });

            TextView tvmsg = convertView.findViewById(R.id.tvmsg);
            TextView tvm = convertView.findViewById(R.id.tv);
            ImageView iv = convertView.findViewById(R.id.iv);


            final Button b2=convertView.findViewById(R.id.b2);

            tvmsg.setText("Image ID "+pd.id+"\nType " +
                    " "+pd.type+"\nDate " +
                    " "+pd.rdate+"\nTime "+pd.rtime
            );
            Picasso.with(context)
                    .load(Global.url + pd.id+".png")
                    .into(iv);






            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        type=pd.type;
                        URL url = new URL(Global.url + "get_medicine");
                        JSONObject jsn = new JSONObject();
                        jsn.put("type",type);


                        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().build();
                        StrictMode.setThreadPolicy(policy);
                        String response = null;
                        response = HttpConnection.getResponse(url, jsn);
                        Log.d("response",response);

                        tvm.setText("Apply "+response);
                       // get_medicine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

        }
        return convertView;
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public int getViewTypeCount() {
        return arrayList.size();
    }
    @Override
    public boolean isEmpty() {
        return false;
    }

    public void get_medicine() throws IOException, JSONException {
        URL url = new URL(Global.url + "get_medicine");
        JSONObject jsn = new JSONObject();
        jsn.put("type",type);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(policy);
        String response = null;
        response = HttpConnection.getResponse(url, jsn);
        Log.d("response",response);

        tv.setText("Apply "+response);



    }


}