package com.example.drone_disease_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Display_Info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_info);
    }
}