package Database;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class DBQuery {

    Connection con = null;
    Statement st = null;
    ResultSet rs = null;

    public int add_leaf_deatils(String type,String date,String time) throws ClassNotFoundException, SQLException
	{
            int rid=0;
		con=DBConnection.getConnection();
		String query1="insert into leaf_details set type='"+type+"',rdate='"+date+"',rtime='"+time+"','')";
		System.out.println(query1);
		st=con.createStatement();
		int i=st.executeUpdate(query1);
                String q = "select MAX(rid) from leaf_details";
                rs=st.executeQuery(q);
                if(rs.next())
                {
                rid=rs.getInt(1);
                }

		return rid;
	}


  
   
  
 public String  check_leaf_details(String type) throws ClassNotFoundException, SQLException {
        String det="";

        String q = "select * from leaf_details where type='" + type + "' ";
        System.out.println("" + q);
        con = DBConnection.getConnection();
        st = con.createStatement();
        rs = st.executeQuery(q);
        while (rs.next()) {

            det=rs.getInt("rid")+"#"+rs.getString("type")+"#"+rs.getString("rdate")+"#"+rs.getString("rtime")+"@@"+det;

        }
        return det;
    }

public String  check_leaf_medicine(String type) throws ClassNotFoundException, SQLException {
        String det="";

        String q = "select * from disease_medicine where disease_type='" + type + "' ";
        System.out.println("" + q);
        con = DBConnection.getConnection();
        st = con.createStatement();
        rs = st.executeQuery(q);
        while (rs.next()) {

            det=rs.getString("medicine");

        }
        return det;
    }
}
