/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author sumit
 */
public class path {
    public static String py_path="C:/Users/nikhi/Downloads/drone_leaf_disease/";
    public static String web="C:/Users/nikhi/Downloads/Drone_Disease_Web/web/";
}
