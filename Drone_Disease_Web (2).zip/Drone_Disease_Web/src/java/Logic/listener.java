/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

import Database.DBQuery;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sumit
 */
public class listener {
    public static void main(String[] args) {
        DBQuery db=new DBQuery();
        while(true)
        {
        try{
            
                    File file = new File("D:/leaf_status.txt"); 
  
                    BufferedReader br = new BufferedReader(new FileReader(file)); 
  
                    String st="",data=""; 
                    while ((st = br.readLine()) != null) 
                    {
                    System.out.println(st);
                    data=st;
                    }
                    
                    if(data.equalsIgnoreCase("Disease"))
                    {
                   
                    String pattern = "dd-MM-yyyy";
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

                    String tdate = simpleDateFormat.format(new Date());
                    System.out.println(tdate);
                        
                    String pattern1 = "hh-mm-ss";
                    SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

                    String tdate1 = simpleDateFormat1.format(new Date());
                    tdate1=tdate1.replace(":", "-");
                    System.out.println(tdate1);
                    int rid=db.add_leaf_deatils(data, tdate, tdate1);
                    File fs=new File(path.py_path+"1.png");
                    File fd=new File(path.web+rid+".png");
                    copyFileUsingStream(fs,fd);
                    File f1=new File("D:/leaf_status.txt");
                    FileOutputStream fout1=new FileOutputStream(f1);
                    fout1.write("".getBytes());
                    fout1.close();
                    }
            
            
        }catch(Exception e)
        {
        e.printStackTrace();
        }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(listener.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
    }
    private static void copyFileUsingStream(File source, File dest) throws IOException {
    InputStream is = null;
    OutputStream os = null;
    try {
        is = new FileInputStream(source);
        os = new FileOutputStream(dest);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = is.read(buffer)) > 0) {
            os.write(buffer, 0, length);
        }
    } finally {
        is.close();
        os.close();
    }
}
}
