package Logic;




import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Receiver {
    
 public static void main(String[] args) throws IOException {

        ServerSocket listener = new ServerSocket(9091);
        try{
            while(true){
                Socket socket = listener.accept();
                socket.setKeepAlive(true);
                System.out.println("Client Connected");
                try{
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String status=in.readLine();
                    System.out.println("Client response: " + status);

                    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    if(!status.equals(""))
                    {
                        
                            File f1=new File("D:/location.txt");
                            FileOutputStream fout1=new FileOutputStream(f1);
                            fout1.write(status.getBytes());
                            fout1.close();
                            
                       
                    }

                   

                
                    out.flush();
                } finally {
                    socket.close();
                }
            }
        } finally {
            listener.close();
        }
    }

}
